const express = require('express')
const cors = require('cors');
const bodyParser = require("body-parser");

const app = express();

app.use(cors());
app.options('*', cors());

app.use(bodyParser.urlencoded({
    extended: true
}));

app.use(bodyParser.json());

app.post('/formdata', (req, res) => {
   res.json({
       message: `Hello, ${req.body.name || '' }, you were born on ${req.body.date || ''}, so you can sign in using email: ${req.body.email || ''} and password: ${req.body.password || ''}`
   })
});

app.listen(3001, function() {
    console.log('Example app listening on port 3001!');
});
