import logo from './logo.svg';
import './App.css';
import {useState} from "react";

function App() {
    const [inputs, setInputs] = useState({});
    const [content, setContent] = useState('')

    const handleChange = (event) => {
        const name = event.target.name;
        const value = event.target.value;
        setInputs(values => ({...values, [name]: value}))
    }

    const handleSubmit = async (e) => {
        e.preventDefault()
        const rawResponse = await fetch('http://localhost:3001/formdata', {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(inputs)
        });

        const content = await rawResponse.json();
        setContent(content?.message)
    }

  return (
    <div className="App">
      <h1>Zadanie3</h1>

        {content ? <h1>{content}</h1> :
            <form onSubmit={handleSubmit}>
                <div>
                    <label htmlFor="name">Enter your name: </label>
                    <input type="text" name="name" id="name" value={inputs.name || ""}
                           onChange={handleChange} required/>
                </div>
                <div>
                    <label htmlFor="email">Enter your email: </label>
                    <input type="email" name="email" id="email" required value={inputs.email || ""}
                           onChange={handleChange}/>
                </div>
                <div>
                    <label htmlFor="password">Enter your password: </label>
                    <input type="password" name="password" id="password" required value={inputs.password || ""}
                           onChange={handleChange}/>
                </div>
                <div>
                    <label htmlFor="date">Enter your birthdate: </label>
                    <input type="date" name="date" id="date" required value={inputs.date || ""}
                           onChange={handleChange}/>
                </div>
                <div>
                    <input type="submit" value="Send!"/>
                </div>
            </form>
        }

    </div>
  );
}

export default App;
