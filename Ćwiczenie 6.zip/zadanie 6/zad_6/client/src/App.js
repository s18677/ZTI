import React, { useEffect, useState } from "react";
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import Form from 'react-bootstrap/Form';


import "bootstrap/dist/css/bootstrap.css";
import "react-bootstrap-table-next/dist/react-bootstrap-table2.min.css";

import BootstrapTable from "react-bootstrap-table-next";
import paginationFactory from "react-bootstrap-table2-paginator";



const columns = [
  {
    dataField: "CustomerId",
    text: "Customer ID",
    sort: true
  },
  {
    dataField: "FirstName",
    text: "First Name",
    sort: true
  },
  {
    dataField: "LastName",
    text: "Last Name"
  },
  {
    dataField: "Company",
    text: "Company"
  },
  {
    dataField: "Email",
    text: "Email"
  }
];

function App() {
  const [data, setData] = useState([])
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  useEffect(() => {
    fetch('http://localhost:4000/customers').then((res) => {
      res.json().then((data) => {
        setData(data.model)}).catch((err) => console.log('err', err))
    }).catch(err => console.log('err', err))
  }, [])


  const [name, setName] = useState('')
  const [lastName, setLastName] = useState('')
  const [company, setCompany] = useState('')
  const [email, setEmail] = useState('')

  const submitData = () => {
    fetch('http://localhost:4000/create', {
  method: 'post',
  headers: {
    'Accept': 'application/json, text/plain, */*',
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({ FirstName: name, LastName: lastName, Company: company, Email: email })
}).then(res => res.json())
  .then(res => console.log(res))
  .catch(err => console.log('err', err));
  }

  return (
    <div className="App">
      <Button variant="primary" onClick={handleShow}>
        Add Customer
      </Button>

      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Add Customer</Modal.Title>
        </Modal.Header>
        <Modal.Body>
        <Form id="submit-form">

        <Form.Group className="mb-3" controlId="formFirstName"   >
            <Form.Label>First Name</Form.Label>
            <Form.Control placeholder="Enter First Name"  value={name} onChange={(e) => setName(e.target.value)}    type="text"/>
          </Form.Group>

          <Form.Group className="mb-3" controlId="formLastName">
            <Form.Label>Last Name</Form.Label>
            <Form.Control placeholder="Enter Last Name"  value={lastName} onChange={(e) => setLastName(e.target.value)} type="text"/>
          </Form.Group>

          <Form.Group className="mb-3" controlId="formCompany" >
            <Form.Label>Company</Form.Label>
            <Form.Control placeholder="Enter Company" value={company} onChange={(e) => setCompany(e.target.value)} type="text"/>
          </Form.Group>

          <Form.Group className="mb-3" controlId="formBasicEmail" >
            <Form.Label>Email address</Form.Label>
            <Form.Control type="email" placeholder="Enter email" value={email} onChange={(e) => setEmail(e.target.value)} type="text"/>
          </Form.Group>

        </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" type="submit" form="submit-form" onClick={() => {
            submitData()
            handleClose()
          }}>
            Submit
          </Button>
        </Modal.Footer>
      </Modal>
      <BootstrapTable
        bootstrap4
        keyField="id"
        data={data}
        columns={columns}
        pagination={paginationFactory({ sizePerPage: 5 })}
      />
    </div>
  );
}

export default App;
