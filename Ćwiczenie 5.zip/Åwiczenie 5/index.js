const express = require('express')
const path = require("path");
const sqlite3 = require('sqlite3').verbose()
const cors = require('cors')
const bodyParser = require('body-parser');

let db;
const app = express()

app.set('view engine', 'ejs');
app.set("views", __dirname + "/views");

app.use(cors())


app.use(bodyParser.urlencoded({
    extended: true
}));

app.use(bodyParser.json());

const dbName = path.join(__dirname, "chinook.db");

const insertUsers = () => {
    const sqlInsert = `INSERT INTO Customer (FirstName, LastName, Company, Email) VALUES
        ('Adam', 'Nowak', 'Samsung', 'adam.nowak@samsung.com'),
        ('Jan', 'Kosmacz', 'Deloitte', 'jan.kosmacz@deloitte.com'),
        ('Jan', 'Kowalski', 'Sony', 'jan.kowalski@sony.com');`;

    db.run(sqlInsert, err => {
        if (err) {
            return console.error(err.message);
        }
        console.log("Successful creation of 3 customers");
    });
}


const createCustomerTable = () => {
    const crateCustomerTableSQL = `CREATE TABLE IF NOT EXISTS Customer(`+
        `   CustomerId INTEGER PRIMARY KEY AUTOINCREMENT,
    FirstName VARCHAR(20) NOT NULL,
    LastName VARCHAR(40) NOT NULL,
    Company VARCHAR(100) NOT NULL,
    Address VARCHAR(100),
    City VARCHAR(100),
    State VARCHAR(100),
    Country VARCHAR(100),
    PostalCode VARCHAR(100),
    Phone VARCHAR(100),
    Fax VARCHAR(100),
    Email VARCHAR(100) NOT NULL,
    SupportRepId VARCHAR(100));
`

    db.run(crateCustomerTableSQL, insertUsers)
}

const clearDatabase = () => db.run('DROP TABLE IF EXISTS Customer', createCustomerTable)

db = new sqlite3.Database(dbName, clearDatabase);


app.get('/', (req, res) => {
    const sql = `SELECT * FROM Customer ORDER BY FirstName`

    db.all(sql, [], (err, rows) => {
        if (err) {
            return console.error(err.message);
        }
        console.log('get hit')
        console.log('rows', rows)
        res.render('response.ejs', { data: rows });
    });
})

app.listen(3000, () => {
    console.log(`Example app listening at http://localhost:3000`)
})
