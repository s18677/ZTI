const express = require('express')
const path = require('path');
const bodyParser = require("body-parser");

const app = express();

app.use(express.urlencoded({
    extended: true
}))
app.use(bodyParser.urlencoded({ extended: false }));

app.set('view engine', 'ejs');
app.set("views", __dirname + "/views");

app.get('/form', (req, res) => {
    res.sendFile(path.join(__dirname+'/index.html'));
});

app.post('/formdata', (req, res) => {
    const data = req.body

    res.render('response.ejs', { data, whatever: 'x' });
});

app.listen(3000, function() {
    console.log('Example app listening on port 3000!');
});
