var sqlite3 = require('sqlite3');

const CREATE_USERS_TABLE_SQL = "CREATE TABLE IF NOT EXISTS users (" +
                                "id integer primary key autoincrement," +
                                "login text not null," +
                                "password text not null," +
                                "email text not null)";

const CREATE_ORDERS_TABLE_SQL = "CREATE TABLE IF NOT EXISTS orders (" +
                                "id integer primary key autoincrement," +
                                "userId integer not null," +
                                "date integer not null," +
                                "price real not null)";

const CREATE_ORDER_ITEMS_TABLE_SQL = "CREATE TABLE IF NOT EXISTS order_items (" +
                                     "orderId integer not null," +
                                     "playlistId integer not null)";

var db = new sqlite3.Database('db/chinook.db', (err) => {
    if(err) {
        return console.error(err.message);
    }
        console.log('Połączono');

        db.run(CREATE_USERS_TABLE_SQL, (err) => {
            if(err) {
                return console.error(err.message);
            }
            console.log("Stworzono tabele users");
        });
        db.run(CREATE_ORDERS_TABLE_SQL, (err) => {
            if(err) {
                return console.error(err.message);
            }
            console.log("Stworzono tabele orders");
        });
        db.run(CREATE_ORDER_ITEMS_TABLE_SQL, (err) => {
            if(err) {
                return console.error(err.message);
            }
            console.log("Stworzono tabele order_items");
        });
});

module.exports = db;
