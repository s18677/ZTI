var express = require('express');
var router = express.Router();
var db = require('../database');

const SELECT_SQL = "SELECT * FROM customers WHERE CustomerId=?";
const UPDATE_SQL = "UPDATE customers SET X = ? WHERE CustomerId = ?";

router.use(function(req, res, next) {
    if(req.session.loggedIn == true) {
        console.log('Zalogowany!');
        next();
    }
    else {
        console.log('Nie zalogowany!');
        res.redirect('/login/form?err=Musisz być zalogowany!');
    }
});

router.get('/:id', function(req, res) {
    var info;
    var id = req.params['id'];

    db.get(SELECT_SQL, id, (err,row) => {
        if(err) {
            return console.error(err.message);
        }
        console.log(`Pobrano ${row}`);
        info = row;
        res.render('update', {title: 'Aktualizacja', row: info, id: id});
    })
});

router.post('/:id/firstname', function(req, res) {
    var id = req.params['id'];
    var sql = UPDATE_SQL.replace('X', 'FirstName');
    var values = [req.body['value'], id];

    db.run(sql, values, (err) => {
        if(err) {
            return console.error(err.message);
        }
        console.log(`Zaktualizowano Imię ${values}`);
        res.redirect(`/update/${id}`);
    });
});

router.post('/:id/lasttname', function(req, res) {
    var id = req.params['id'];
    var sql = UPDATE_SQL.replace('X', 'LastName');
    var values = [req.body['value'], id];

    db.run(sql, values, (err) => {
        if(err) {
            return console.error(err.message);
        }
        console.log(`Zaktualizowano Nazwisko ${values}`);
        res.redirect(`/update/${id}`);
    });
});

router.post('/:id/company', function(req, res) {
    var id = req.params['id'];
    var sql = UPDATE_SQL.replace('X', 'Company');
    var values = [req.body['value'], id];

    db.run(sql, values, (err) => {
        if(err) {
            return console.error(err.message);
        }
        console.log(`Zaktualizowano Firmę ${values}`);
        res.redirect(`/update/${id}`);
    });
});

router.post('/:id/address', function(req, res) {
    var id = req.params['id'];
    var sql = UPDATE_SQL.replace('X', 'Address');
    var values = [req.body['value'], id];

    db.run(sql, values, (err) => {
        if(err) {
            return console.error(err.message);
        }
        console.log(`Zaktualizowano Adres ${values}`);
        res.redirect(`/update/${id}`);
    });
});

router.post('/:id/city', function(req, res) {
    var id = req.params['id'];
    var sql = UPDATE_SQL.replace('X', 'City');
    var values = [req.body['value'], id];

    db.run(sql, values, (err) => {
        if(err) {
            return console.error(err.message);
        }
        console.log(`Zaktualizowano Miasto ${values}`);
        res.redirect(`/update/${id}`);
    });
});

router.post('/:id/state', function(req, res) {
    var id = req.params['id'];
    var sql = UPDATE_SQL.replace('X', 'State');
    var values = [req.body['value'], id];

    db.run(sql, values, (err) => {
        if(err) {
            return console.error(err.message);
        }
        console.log(`Zaktualizowano Stan ${values}`);
        res.redirect(`/update/${id}`);
    });
});

router.post('/:id/country', function(req, res) {
    var id = req.params['id'];
    var sql = UPDATE_SQL.replace('X', 'Country');
    var values = [req.body['value'], id];

    db.run(sql, values, (err) => {
        if(err) {
            return console.error(err.message);
        }
        console.log(`Zaktualizowano Kraj ${values}`);
        res.redirect(`/update/${id}`);
    });
});

router.post('/:id/postalcode', function(req, res) {
    var id = req.params['id'];
    var sql = UPDATE_SQL.replace('X', 'PostalCode');
    var values = [req.body['value'], id];

    db.run(sql, values, (err) => {
        if(err) {
            return console.error(err.message);
        }
        console.log(`Zaktualizowano Kod pocztowy ${values}`);
        res.redirect(`/update/${id}`);
    });
});

router.post('/:id/phone', function(req, res) {
    var id = req.params['id'];
    var sql = UPDATE_SQL.replace('X', 'Phone');
    var values = [req.body['value'], id];

    db.run(sql, values, (err) => {
        if(err) {
            return console.error(err.message);
        }
        console.log(`Zaktualizowano Telefon ${values}`);
        res.redirect(`/update/${id}`);
    });
});

router.post('/:id/fax', function(req, res) {
    var id = req.params['id'];
    var sql = UPDATE_SQL.replace('X', 'Fax');
    var values = [req.body['value'], id];

    db.run(sql, values, (err) => {
        if(err) {
            return console.error(err.message);
        }
        console.log(`Zaktualizowano Fax ${values}`);
        res.redirect(`/update/${id}`);
    });
});

router.post('/:id/email', function(req, res) {
    var id = req.params['id'];
    var sql = UPDATE_SQL.replace('X', 'Email');
    var values = [req.body['value'], id];

    db.run(sql, values, (err) => {
        if(err) {
            return console.error(err.message);
        }
        console.log(`Zaktualizowano Email ${values}`);
        res.redirect(`/update/${id}`);
    });
});
module.exports = router;
