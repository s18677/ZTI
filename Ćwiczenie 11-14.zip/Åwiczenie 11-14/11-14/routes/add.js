var express = require('express');
var router = express.Router();
var db = require('../database');

const INSERT_SQL = "INSERT INTO Customers ('FirstName','LastName','Company','Address','City','State','Country','PostalCode','Phone','Fax','Email','SupportRepId') VALUES";

router.post('/', function(req, res) {
    var values = ' (';

    for(var i=1; i<12; i++) {
        values += "'"+req.body[`${i}`] + "',";
    }
    values += "'"+req.body['12'] + "');";

    var sql = INSERT_SQL + values;
    db.run(sql, (err) => {
        if(err) {
            return console.error(err.message);
        }
        console.log("Pomyślnie dodano rekord: " + sql);
    });
    
});

module.exports = router;
