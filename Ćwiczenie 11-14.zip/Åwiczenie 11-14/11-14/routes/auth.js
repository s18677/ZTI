var express = require('express');
var router = express.Router();
var db = require('../database');

const SELECT_PLAYLISTS_SQL = "SELECT * FROM playlists WHERE PlaylistId IN ";
const INSERT_ORDER_SQL = "INSERT INTO orders (userId, date, price) VALUES ";
const INSERT_ORDER_ITEM_SQL = "INSERT INTO order_items (orderId, playlistId) VALUES ";
const SELECT_USER_ORDERS_SQL = "SELECT id, date, price FROM orders WHERE userId == ?";
const SELECT_USER_ORDER_ITEMS_SQL = "SELECT playlists.Name as name " +
                                " FROM playlists " +
                                " INNER JOIN order_items ON order_items.playlistId == playlists.PlaylistId " +
                                " WHERE order_items.orderId == ? ";

router.use(function(req, res, next) {
    if(req.session.loggedIn == true) {
        console.log('Zalogowany!');
        next();
    }
    else {
        console.log('Nie zalogowany!');
        res.redirect('/login/form?err=Musisz być zalogowany!');
    }
});

router.get('/cart', function(req, res) {
    var cart = req.session.cart;
    var cartString = "(" + cart + ")";
    var select = SELECT_PLAYLISTS_SQL + cartString;
    db.all(select, (err, rows) => {
        if(err) {
          return console.error(err.message);
      }
          console.log(`Pobrano playlisty z koszyka`);
          res.render('cart', { title: 'Koszyk', userName: req.session.userName, rows: rows});
      })
});

router.post('/cart/add/:id', function(req, res) {
    var id = req.params['id'];
    var cart = req.session.cart;
    var index = cart.indexOf(id);

    if(index == -1) {
        cart = [...cart, id];
        req.session.cart = cart;
        console.log(`Koszyk: ${cart}`);
        res.send('<p> Dodano do koszyka </p>')
    }
    else {
        res.send('<p> Playlista znajduje się już w koszyku </p>')
    }
    
});

router.post('/cart/remove/:id', function(req, res) {
    var id = req.params['id'];
    var cart = req.session.cart;
    var index = cart.indexOf(id);

    if(index != -1) {
        cart.splice(index, 1);
        req.session.cart = cart;
        console.log(`Koszyk: ${cart}`);
        res.redirect('/auth/cart');
    }
    else {
        res.send("<p> Nie istnieje taki element</p>")
    }
});

router.get('/cart/orders', function(req, res) {
    var userId = req.session.userId;
    var orders = [];

    db.serialize(() => {
        db.all(SELECT_USER_ORDERS_SQL, userId, (err, order_rows) => {
            if(err) {
                return console.error(err.message);
            }
            console.log(`Pobrano zamówienia użytkownika`);
            
            if(order_rows.length != 0) {
                var itr = 0;
                var len = order_rows.length;
                order_rows.forEach(order_row => {
                    db.all(SELECT_USER_ORDER_ITEMS_SQL, order_row.id, (err, item_rows) => {
                        if(err) {
                            return console.error(err.message);
                        }
                        var orderId = order_row.id;
                        var date_ms = order_row.date;
                        var price = order_row.price;
                        var date = new Date(date_ms);
                        var date_string = date.getDate() + "." + date.getMonth() + "." + date.getFullYear() +
                                            " " + date.getHours() + ":" + date.getMinutes();
    
                        orders = [...orders, {"id": orderId, "date": date_string, "price": price, "items": item_rows}];
    
                        itr++;
                        if(itr == len) {
                            res.render('orders', {title: "Historia zamówień", orders: orders});
                        }
    
                    });
    
                }) 
            }
            else {
                res.render('orders', {title: "Historia zamówień", orders: orders});
            }
        });
    });

});

router.get('/cart/order', function(req, res) {
    var cart = req.session.cart;
    var cartString = "(" + cart + ")";
    var select = SELECT_PLAYLISTS_SQL + cartString;
    db.all(select, (err, rows) => {
        if(err) {
          return console.error(err.message);
      }
          console.log(`Załadowano playlisty do podsumowania`);
          res.render('order', { title: 'Podsumowanie', rows: rows});
      })
});

router.post('/cart/order', function(req, res) {
    var date = Date.now();
    var id = req.session.userId;
    var cart_ids = req.session.cart;
    var insert_values = [id, date, 100.0];
    var insert_values_string = "(" + insert_values + ")";
    var insert_id = -1;
    var insert = INSERT_ORDER_SQL + insert_values_string;
    db.run(insert, function(err) {
        if(err) {
            return console.error(err.message);
        }
        insert_id = this.lastID;
        console.log(`Dodano zamówienie`)

        insert_values_string = "";

        cart_ids.forEach(element => {
            var values = [insert_id, element]
            var values_string = ["(" + values + ")"]
            insert_values_string += values_string + ",";
            
        });
            insert_values_string = insert_values_string.slice(0, -1);    
            insert = INSERT_ORDER_ITEM_SQL + insert_values_string;
        db.run(insert, (err) => {
            if(err) {
                return console.error(err.message);
            }
            console.log(`Dodano elementy zamówienia`)

            req.session.cart = [];
            res.redirect(`/`)
        });
    });
       
});

module.exports = router;
