var express = require('express');
var router = express.Router();
var db = require('../database');

const SELECT_PLAYLISTS_SQL = "SELECT * FROM playlists";
const SELECT_PLAYLIST_DETAILS_SQL = "SELECT tracks.Name as trackName, albums.Title as albumName, tracks.Composer as composer, tracks.UnitPrice as Price " +
                            " FROM playlists " +
                            " INNER JOIN playlist_track ON playlist_track.PlaylistId == playlists.PlaylistId " +
                            " INNER JOIN tracks ON tracks.TrackId == playlist_track.TrackId " +
                            " INNER JOIN albums ON albums.AlbumId == tracks.AlbumId " +
                            " WHERE playlists.PlaylistId == ? ";

router.get('/all', function(req, res) {
    db.all(SELECT_PLAYLISTS_SQL, (err, rows) => {
        if(err) {
          return console.error(err.message);
      }
          console.log(`Pobrano wszystkie playlisty`);
          res.render('playlists', { title: 'Playlisty', rows: rows});
      })
});

router.get('/details/:id', function(req, res) {
    var id = req.params['id'];
    var name = req.query['name'];

    db.all(SELECT_PLAYLIST_DETAILS_SQL, id, (err, rows) => {
        if(err) {
            return console.error(err.message);
        }

        console.log(`Pobrano detale playlisty`);
        res.render('playlist_details', {title: `Playlista: ${name}`, playlistName: name, playlistId: id, rows: rows})
    });
});

module.exports = router;
