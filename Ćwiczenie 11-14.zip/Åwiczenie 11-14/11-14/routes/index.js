var express = require('express');
var router = express.Router();
var db = require('../database');
var bcrypt = require('bcrypt');
const salt_rounds = 12;

const SELECT_SQL = "SELECT CustomerId, FirstName, LastName, Company, Address FROM customers LIMIT 10 OFFSET";
const INSERT_USER_SQL = "INSERT INTO users ('login', 'email', 'password') VALUES (?, ?, ?)";
const USER_EXISTS_SQL = "SELECT * FROM users WHERE login = ? or email = ?"
const REGISTER_ERROR = "Niepoprawne dane lub użytkownik istnieje!";
const LOGIN_ERROR = "Niepoprawne dane lub użytkownik nie istnieje!";
router.get('/', function(req, res)  {
  res.redirect('http://127.0.0.1:3000/1')
});


router.get('/:page', function(req, res, next) {
  var pageNum = parseInt(req.params['page']);
  var offset = (10 * pageNum) - 10;
  var getPageSql = SELECT_SQL + ` ${offset};`;

  db.all(getPageSql, (err, rows) => {
    if(err) {
      return console.error(err.message);
  }
      console.log(`Załadowano stronę nr ${pageNum}`);
      res.render('index', { title: 'DB', page: pageNum, rows: rows, loggedIn: req.session.loggedIn });
  }) 
});

router.get('/login/form', function(req, res) {
  var err = req.query['err'];
  res.render('login', {title: "Logowanie", error: err})
});

router.post('/login', function(req, res) {
  login = req.body['login'];
  password = req.body['password'];

  db.get(USER_EXISTS_SQL, [login, ''], (err, row) => {
    if(err) {
      return console.error(err.message);
    }
    if(row === undefined) {
      res.redirect(`/login/form?err=${LOGIN_ERROR}`)
    }
    else {
      bcrypt.compare(password, row.password, (err, result) => {
        if(err) {
          return console.error(err.message);
        }

        if(result == true) {
          req.session.loggedIn = true;
          req.session.userId = row.id;
          req.session.userName = login;
          req.session.password = row.password;
          req.session.cart = [];
          res.redirect('/');
        }
        else {
          res.redirect(`/login/form?err=${LOGIN_ERROR}`)
        }
      })
    }
  })
});

router.get('/register/form', function(req, res) {
  var err = req.query['err'];
  res.render('register', {title: "Rejestracja", error: err})
});

router.post('/register', function(req, res) {
  login = req.body['login'];
  email = req.body['email'];
  password = req.body['password'];

  if(login === "" || login == null || email === "" || email == null || password === "" || password == null) {
    res.redirect(`/register/form?err=${REGISTER_ERROR}`);
  }
  else {
    db.get(USER_EXISTS_SQL, [login, email], (err, row) => {
        if(err) {
            return console.error(err.message);
        }
        console.log(`Sprawdzono, czy użytkownik już istnieje`)

        if(row === undefined) {
            bcrypt.hash(password, salt_rounds, (err, hash) => {
                if(err) {
                    return console.error(err.message)
                }

                db.run(INSERT_USER_SQL, [login, email, hash], (err) => {
                    if(err) {
                        return console.error(err.message);
                    }
                    console.log(`Dodano użytkownika`);
                    res.redirect(`/login/form`);
                })
            })
            
        }
        else {
            console.log(`${login} już istnieje`)
            res.redirect(`register/form?err=${REGISTER_ERROR}`)
        }
    })
}
});

router.post('/logout', function(req, res) {
  if(req.session.userName !== undefined) {
    user = req.session.userName;
    req.session.loggedIn = false;
    req.session.destroy((err) => {
        if(err) {
            return console.error(err.message);
        }

        res.redirect('/')
    })
}
else {
    res.redirect('/login/form?err=Sesja przedawniona')
}
});

module.exports = router;
