var express = require('express');
var router = express.Router();
var db = require('../database');

const DELETE_SQL = "DELETE FROM customers WHERE CustomerId=?";
const SELECT_SQL = "SELECT * FROM customers WHERE CustomerId=?";

router.use(function(req, res, next) {
    if(req.session.loggedIn == true) {
        console.log('Zalogowany!');
        next();
    }
    else {
        console.log('Nie zalogowany!');
        res.redirect('/login/form?err=Musisz być zalogowany!');
    }
});

router.get('/:id', function(req, res) {
    var info;
    var id = req.params['id'];    

    db.serialize(() => {
        db.get(SELECT_SQL, id, (err,row) => {
            if(err) {
                return console.error(err.message);
            }
            console.log(`Pobrano ${row}`);
            info = row;
        })

        db.run(DELETE_SQL, id, (err) => {
            if(err) {
                return console.error(err.message);
            }
            console.log(`Usunięto ${info}`);
            res.render('delete', {title: 'Usunięto', row: info} );
        })
    });
});

module.exports = router;
