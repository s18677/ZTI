var express = require('express');
var router = express.Router();
var db = require('../database');

const SELECT = "SELECT * FROM Customers WHERE CustomerId = ?";
const UPDATE =`UPDATE Customers SET FirstName=?, LastName=?, Company=?,
                                    Address=?, City=?, State=?,
                                    Country=?, PostalCode=?, Phone=?,
                                    Fax=?, Email=?
                                    WHERE CustomerId=?`;
const DELETE = "DELETE FROM Customers WHERE CustomerId = ?";


router.get('/info/:id', function(req, res) {
    if(req.session.isLoggedIn == true) {
        id = req.params['id']
        db.get(SELECT, id, (err, result) => {
            if(err) {
                return console.error(`get /info/${id} ${err.message}`);
            }
            console.log(`Wykonano ${SELECT}`);
            res.render('customer_info', {title: 'Więcej informacji', row: result, page: req.query['page']})
        })
    }
    else {
        res.redirect('/1?info=Musisz być zalogowany');
    }
    
});

router.get('/edit/:id', function(req, res) {
    if(req.session.isLoggedIn == true) {
        id = req.params['id']
        db.get(SELECT, id, (err, result) => {
            if(err) {
                return console.error(`get /edit/${id} ${err.message}`);
            }
            console.log(`Wykonano ${SELECT}`);
            res.render('customer_edit', {title: 'Edytuj klienta', row: result, page: req.query['page']})
        })
    }
    else {
        res.redirect('/1?info=Musisz być zalogowany');
    }
});

router.post('/edit/:id', function(req, res) {
    if(req.session.isLoggedIn == true) {
        var data = [];
        var id = req.params['id'];
        var page = req.query['page'];
        for(var i=1; i<12; i++) {
            data = [...data, req.body[`${i}`]];
        }
        data = [...data, id];

        db.run(UPDATE, data, (err) => {
            if(err) {
                return console.error(`post /edit/${id} ${err.message}`);
            }
            console.log(`Wyonano ${UPDATE} dla ${data}`);
            res.redirect(`/customer/edit/${id}?page=${page}`);
        })
    }
    else {
        res.redirect('/1?info=Musisz być zalogowany');
    }
});

router.get('/delete/:id', function(req, res) {
    if(req.session.isLoggedIn == true) {
        var page = req.query['page'];
        var id = req.params['id'];

        db.run(DELETE, id, (err) => {
            if(err) {
                return console.error(`get /delete/${id} ${err.message}`);
            }
            console.log(`Wyonano ${DELETE} dla ${id}`);
            res.redirect(`/${page}`);
        })
    }
    else {
        res.redirect('/1?info=Musisz być zalogowany');
    } 
})

module.exports = router;
