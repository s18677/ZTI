document.getElementById("my_input").addEventListener("keyup", (e) => {
        if (e.keyCode == 13) {
          document.getElementById("my_button").click();
          event.preventDefault();
        }
      });
      const sendInput = () => {
        let x = document.getElementById("my_input").value;
        let contentBody = document.getElementById("content_body");
        let newLine = document.createElement("br");

        if (x) {
          const newText = document.createElement("p");
          newText.innerHTML = x;
          contentBody.appendChild(newLine);
          contentBody.appendChild(newText.firstChild);
        }
        contentBody.scrollTop = contentBody.scrollHeight;
        document.getElementById("my_input").value = "";
      };