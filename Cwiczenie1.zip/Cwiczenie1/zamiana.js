 const validate = () => {
        const numericValue = document.forms["form_miles_to_km"]["numeric"].value;

        const convertMilesToKm = (miles) => {
          const km = miles * 1.609;
          document.getElementById("result").value = km + " km";
        };

        const numericFunc = (miles) => {
          if (isNaN(miles) || !miles) {
            document.getElementById("info1").innerHTML =
              "Podaj liczbę";
            document.getElementById("result").value = "";
            return false;
          }
          document.getElementById("info1").innerHTML = "";
          return true;
        };
        numericFunc(numericValue) && convertMilesToKm(numericValue);
      };