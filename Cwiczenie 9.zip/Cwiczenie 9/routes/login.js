var express = require('express');
var router = express.Router();
var db = require('../database');
const bcrypt = require('bcrypt');

const CHECK_IF_USER_EXISTS = "SELECT * FROM users WHERE login=?"
const ERROR_LOGIN = "Błędne hasło lub login"
router.post('/', function(req, res) {
    login = req.body['login'];
    password = req.body['password'];

    db.get(CHECK_IF_USER_EXISTS, login, (err, row) => {
      if(err) {
        return console.error(`post /login select ${err.message}`);
      }
      if(row === undefined) {
        res.redirect(`1/?loginError=${ERROR_LOGIN}`)
      }
      else {
        bcrypt.compare(password, row.password, (err, result) => {
          if(err) {
            return console.error(`post /login compare ${err.message}`);
          }

          if(result == true) {
            res.redirect('/1?info=Zalogowano');
          }
          else {
            res.redirect(`1/?loginError=${ERROR_LOGIN}`)
          }
        })
      }
    })
});

module.exports = router;
