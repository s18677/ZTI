var sqlite3 = require('sqlite3');

var db = new sqlite3.Database('db/chinook.db', (err) => {
    if(err) {
        return console.error(err.message);
    }
        console.log('Połączono z bazą');
});

module.exports = db;
