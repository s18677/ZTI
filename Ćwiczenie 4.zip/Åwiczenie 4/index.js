const sqlite3 = require('sqlite3').verbose();
let db;

function createDb() {
    db = new sqlite3.Database('chain.sqlite3', createTable);
}


function createTable() {
    db.run('CREATE TABLE IF NOT EXISTS langs(name TEXT, description TEXT)', insertRows);
}

function insertRows() {
    const data = [
        ['English', 'Hello World'],
        ['Polski', 'Witaj Świecie'],
        ['Deutsch', 'Hallo Welt'],
        ['Dansk', 'Hej velt']
    ]
    const stmt = db.prepare(`INSERT INTO langs(name, description) VALUES(?, ?)`);

    for (let i = 0; i < data.length; i++) {
        stmt.run([data[i][0], data[i][1]]);
    }

    stmt.finalize(readAllRows);
}

function readAllRows() {
    db.all("SELECT * from langs", function(err, rows) {
        rows.forEach(function (row) {
            console.log(row.name + ', '+ row.description);
        });
        closeDb();
    });
}

function closeDb() {
    db.run('DROP TABLE IF EXISTS langs')
    db.close();
}

function runChainExample() {
    createDb();
}

runChainExample();
