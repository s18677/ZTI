function delete_confirmation(id, page) {
    confirmation = confirm("Czy napewno chcesz usunąć?");

    if(confirmation) {
        window.location.href = `http://127.0.0.1:3000/customer/delete/${id}?page=${page}`;
    }
}