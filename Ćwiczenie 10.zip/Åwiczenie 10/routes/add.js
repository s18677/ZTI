var express = require('express');
var router = express.Router();
var db = require('../database');

const INSERT = "INSERT INTO Customers ('FirstName','LastName','Company','Address','City','State','Country','PostalCode','Phone','Fax','Email','SupportRepId') VALUES";


router.post('/', function(req, res) {
    var values = ' (';

    for(var i=1; i<12; i++) {
        values += "'"+req.body[`${i}`] + "',";
    }
    values += "'"+req.body['12'] + "');";

    var sql = INSERT + values;
    console.log(sql);
    db.run(sql, (err) => {
        if(err) {
            return console.error(`post /add ${err.message}`);
        }
        console.log("Wykonano:"+ sql);
        //res.redirect(req.path);
    });

});


module.exports = router;
