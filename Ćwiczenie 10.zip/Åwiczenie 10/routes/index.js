var express = require('express');
var router = express.Router();
var db = require('../database');

const SELECT = "SELECT CustomerId, FirstName, LastName, Company, Address FROM customers LIMIT 10 OFFSET";

/* GET home page. */
router.get('/', function(req, res)  {
  res.redirect('http://127.0.0.1:3000/1')
});


router.get('/:page', function(req, res) {
  var pageNum = parseInt(req.params['page']);
  var offset = (10 * pageNum) - 10;
  var pageSelect = SELECT + ` ${offset};`;

  var info = req.query['info'];
  var loginError = req.query['loginError'];
  var isLoggedIn = req.session.isLoggedIn;

  db.all(pageSelect, (err, rows) => {
    if(err) {
      return console.error(`get /${pageNum} ${err.message}`);
  }
      console.log(`Wykonano ${pageSelect}`);
      res.render('index', { title: 'Strona główna', page: pageNum, rows: rows, info: info, loginError: loginError, isLoggedIn: isLoggedIn});
  })
  
});

module.exports = router;
