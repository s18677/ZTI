var express = require('express');
var router = express.Router();
var db = require('../database');


router.post('/', function(req, res) {
    if(req.session.user !== undefined) {
        user = req.session.user;
        req.session.isLoggedIn = false;
        req.session.destroy((err) => {
            if(err) {
                return console.error(`post /logout session.destroy ${err.message}`);
            }
    
            res.redirect(`/1?info=Wylogowano ${user}`)
        })
    }
    else {
        res.redirect(`/1?info=Nikt nie był zalogowany`)
    }
    
});

module.exports = router;
