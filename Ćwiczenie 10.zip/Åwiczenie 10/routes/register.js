var express = require('express');
var router = express.Router();
var db = require('../database');
const bcrypt = require('bcrypt');
const saltRounds = 10;

const CHECK_IF_USER_EXISTS = "SELECT * FROM users WHERE login=? or email=?"
const INSERT_USER = "INSERT INTO users ('login', 'email', 'password') VALUES (?, ?, ?)";
const ERROR_INPUT = "Wszystkie pola muszą zostać wypełnione";
const ERROR_USER_EXISTS = "Użytkownik już istnieje";


router.get('/form', function(req, res) {
    res.render('register', {title: 'Rejestracja', error: ''})
});

router.post('/', function(req, res) {
    login = req.body['login'];
    email = req.body['email'];
    password = req.body['password'];

    if(login === "" || login == null || email === "" || email == null || password === "" || password == null) {
        res.render('register', {title: 'Rejestracja', error: ERROR_INPUT})
    }
    else {
        db.get(CHECK_IF_USER_EXISTS, [login, email], (err, row) => {
            if(err) {
                return console.error(`post /register select ${err.message}`);
            }
            console.log(`Wykonano ${CHECK_IF_USER_EXISTS}`)

            if(row === undefined) {
                bcrypt.hash(password, saltRounds, (err, hash) => {
                    if(err) {
                        return console.error(`post /register hash ${err.message}`)
                    }

                    db.run(INSERT_USER, [login, email, hash], (err) => {
                        if(err) {
                            return console.error(`post /register insert ${err.message}`);
                        }
                        console.log(`Wykonano ${INSERT_USER}`)
                        res.redirect(`/1?info=Utworzono użytkownika ${login}`)
                    })
                })
                
            }
            else {
                console.log(`${login} już istnieje`)
                res.render('register', {title: 'Rejestracja', error: ERROR_USER_EXISTS})
            }
        })
    }
});



module.exports = router;
