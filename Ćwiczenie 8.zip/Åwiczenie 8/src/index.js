const express = require('express')
const cors = require('cors')
const bodyParser = require('body-parser');
const controller = require('./controller');

const app = express()

app.use(cors())
// configure the app to use bodyParser()
app.use(bodyParser.urlencoded({
  extended: true
}));

app.use(bodyParser.json());

app.use('/', controller)

app.listen(4000, () => {
  console.log(`Example app listening at http://localhost:4000`)
})

