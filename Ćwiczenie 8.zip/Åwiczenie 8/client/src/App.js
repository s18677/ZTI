import React, { useEffect, useState } from "react";
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import Form from 'react-bootstrap/Form';


import "bootstrap/dist/css/bootstrap.css";
import "react-bootstrap-table-next/dist/react-bootstrap-table2.min.css";

import BootstrapTable from "react-bootstrap-table-next";
import paginationFactory from "react-bootstrap-table2-paginator";
import { useNavigate } from "react-router-dom"
import axios from 'axios'

function Actions({cell, row, rowIndex, formatExtraData}) {

  const navigate = useNavigate()


  return (
   <>
   <Button variant="info" onClick={ () => navigate(`/details/:${row?.CustomerId}`)}>Info</Button>{' '}
   <Button variant="secondary" onClick={ () => navigate(`/edit/:${row?.CustomerId}`)}>Edit</Button>{' '}
   <Button variant="danger" onClick={() => axios.delete(`http://localhost:4000/delete?id=${row?.CustomerId}`).then((res) => console.log('res', res)).catch(err => console.log('err', err))}>Delete</Button>
   </>
  );
}

const columns = [
  {
    dataField: "CustomerId",
    text: "Customer ID",
    sort: true
  },
  {
    dataField: "FirstName",
    text: "First Name",
    sort: true
  },
  {
    dataField: "LastName",
    text: "Last Name"
  },
  {
    dataField: "Company",
    text: "Company"
  },
  {
    dataField: "Email",
    text: "Email"
  },
  {  dataField: 'CustomerId',
  text: 'Actions',
  formatter: (cell, row, rowIndex, formatExtraData) => <Actions cell={cell} row={row} rowIndex={rowIndex} formatExtraData={formatExtraData}/>,

}
];

function App() {
  const [data, setData] = useState([])
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  useEffect(() => {
    fetch('http://localhost:4000/customers').then((res) => {
      res.json().then((data) => {
        setData(data.model)}).catch((err) => console.log('err', err))
    }).catch(err => console.log('err', err))
  }, [])


  const [name, setName] = useState('')
  const [lastName, setLastName] = useState('')
  const [company, setCompany] = useState('')
  const [email, setEmail] = useState('')
  const [address, setAddress] = useState('')
  const [city, setCity] = useState('')
  const [country, setCountry] = useState('')
  const [state, setState] = useState('')
  const [postalCode, setPostalCode] = useState('')
  const [phone, setPhone] = useState('')
  const [fax, setFax] = useState('')

  const submitData = () => {
    fetch('http://localhost:4000/create', {
  method: 'post',
  headers: {
    'Accept': 'application/json, text/plain, */*',
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({ FirstName: name, LastName: lastName, Company: company, Email: email, Address: address,
    City: city,
    State: state,
    Country: country,
    PostalCode: postalCode,
    Phone: phone,
    Fax: fax })
}).then(res => res.json())
  .then(res => console.log(res))
  .catch(err => console.log('err', err));
  }

  return (
    <div className="App">
      <Button variant="primary" onClick={handleShow}>
        Add Customer
      </Button>

      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Add Customer</Modal.Title>
        </Modal.Header>
        <Modal.Body>
        <Form id="submit-form">

        <Form.Group className="mb-3" controlId="formFirstName"   >
            <Form.Label>First Name</Form.Label>
            <Form.Control placeholder="Enter First Name"  value={name} onChange={(e) => setName(e.target.value)}    type="text"/>
          </Form.Group>

          <Form.Group className="mb-3" controlId="formLastName">
            <Form.Label>Last Name</Form.Label>
            <Form.Control placeholder="Enter Last Name"  value={lastName} onChange={(e) => setLastName(e.target.value)} type="text"/>
          </Form.Group>

          <Form.Group className="mb-3" controlId="formCompany" >
            <Form.Label>Company</Form.Label>
            <Form.Control placeholder="Enter Company" value={company} onChange={(e) => setCompany(e.target.value)} type="text"/>
          </Form.Group>

          <Form.Group className="mb-3" controlId="formBasicEmail" >
            <Form.Label>Email address</Form.Label>
            <Form.Control type="email" placeholder="Enter email" value={email} onChange={(e) => setEmail(e.target.value)} type="text"/>
          </Form.Group>

          <Form.Group className="mb-3" controlId="formBasicEmail" >
            <Form.Label>Country</Form.Label>
            <Form.Control placeholder="Enter Country" value={country} onChange={(e) => setCountry(e.target.value)} type="text"/>
          </Form.Group>

          <Form.Group className="mb-3" controlId="formBasicEmail" >
            <Form.Label>State</Form.Label>
            <Form.Control placeholder="Enter State" value={state} onChange={(e) => setState(e.target.value)} type="text"/>
          </Form.Group>

          <Form.Group className="mb-3" controlId="formBasicEmail" >
            <Form.Label>City</Form.Label>
            <Form.Control placeholder="Enter City" value={city} onChange={(e) => setCity(e.target.value)} type="text"/>
          </Form.Group>

          <Form.Group className="mb-3" controlId="formBasicEmail" >
            <Form.Label>PostalCode</Form.Label>
            <Form.Control placeholder="Enter PostalCode" value={postalCode} onChange={(e) => setPostalCode(e.target.value)} type="text"/>
          </Form.Group>

          <Form.Group className="mb-3" controlId="formBasicEmail" >
            <Form.Label>Address</Form.Label>
            <Form.Control placeholder="Enter Address" value={address} onChange={(e) => setAddress(e.target.value)} type="text"/>
          </Form.Group>

          <Form.Group className="mb-3" controlId="formBasicEmail" >
            <Form.Label>Phone</Form.Label>
            <Form.Control placeholder="Enter Phone" value={phone} onChange={(e) => setPhone(e.target.value)} type="text"/>
          </Form.Group>

          <Form.Group className="mb-3" controlId="formBasicEmail" >
            <Form.Label>Fax</Form.Label>
            <Form.Control placeholder="Enter Fax" value={fax} onChange={(e) => setFax(e.target.value)} type="text"/>
          </Form.Group>
          
      
        </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" type="submit" form="submit-form" onClick={() => {
            submitData()
            handleClose()
          }}>
            Submit
          </Button>
        </Modal.Footer>
      </Modal>
      <BootstrapTable
        bootstrap4
        keyField="id"
        data={data}
        columns={columns}
        pagination={paginationFactory({ sizePerPage: 5 })}
      />
    </div>
  );
}

export default App;
