import React, { useEffect, useState } from 'react'
import axios from 'axios'
import ListGroup from 'react-bootstrap/ListGroup';


const DetailedInfo = () => {

    useEffect(() => {

        const id = window.location.href.split(":").pop()

        axios.get(`http://localhost:4000/customer?id=${id}`).then((res) => {
            console.log('res', res)

            setResponse(res.data?.model[0])
        })
        .catch(err => {
            console.log('err', err)
        })
    }, [])

    const [response, setResponse] = useState({})



    const {FirstName, LastName, Company, Email,Country, State, City, PostalCode, Address, Phone, Fax } = response || {}

    return(
        <ListGroup>
            
            <ListGroup.Item>First Name</ListGroup.Item>
            <ListGroup.Item>{FirstName}</ListGroup.Item>
          
            <ListGroup.Item>Last Name</ListGroup.Item>
            <ListGroup.Item>{LastName}</ListGroup.Item>

            <ListGroup.Item>Company</ListGroup.Item>
            <ListGroup.Item>{Company}</ListGroup.Item>

            <ListGroup.Item>Email</ListGroup.Item>
            <ListGroup.Item>{Email}</ListGroup.Item>

            <ListGroup.Item>Country</ListGroup.Item>
            <ListGroup.Item>{Country}</ListGroup.Item>

            <ListGroup.Item>State</ListGroup.Item>
            <ListGroup.Item>{State}</ListGroup.Item>

            <ListGroup.Item>City</ListGroup.Item>
            <ListGroup.Item>{City}</ListGroup.Item>

            <ListGroup.Item>Postal Code</ListGroup.Item>
            <ListGroup.Item>{PostalCode}</ListGroup.Item>

            <ListGroup.Item>Address</ListGroup.Item>
            <ListGroup.Item>{Address}</ListGroup.Item>

            <ListGroup.Item>Phone</ListGroup.Item>
            <ListGroup.Item>{Phone}</ListGroup.Item>

            <ListGroup.Item>Fax</ListGroup.Item>
            <ListGroup.Item>{Fax}</ListGroup.Item>
        </ListGroup>
    )

}


export default DetailedInfo