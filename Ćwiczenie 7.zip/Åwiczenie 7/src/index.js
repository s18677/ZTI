const express = require('express')
const path = require("path");
const sqlite3 = require('sqlite3').verbose()
const cors = require('cors')
var bodyParser = require('body-parser');


const app = express()

app.use(cors())
// configure the app to use bodyParser()
app.use(bodyParser.urlencoded({
  extended: true
}));
app.use(bodyParser.json());

const dbName = path.join(__dirname, "db", "chinook.db");

const db = new sqlite3.Database(dbName, err => {
  if (err) {
    return console.error(err.message);
  }
  console.log("Successful connection to the database 'chinook.db'");
});

const crateCustomerTableSQL = `CREATE TABLE IF NOT EXISTS Customer(`+ 
`   CustomerId INTEGER PRIMARY KEY AUTOINCREMENT,
    FirstName VARCHAR(20) NOT NULL,
    LastName VARCHAR(40) NOT NULL,
    Company VARCHAR(100) NOT NULL,
    Address VARCHAR(100),
    City VARCHAR(100),
    State VARCHAR(100),
    Country VARCHAR(100),
    PostalCode VARCHAR(100),
    Phone VARCHAR(100),
    Fax VARCHAR(100),
    Email VARCHAR(100) NOT NULL,
    SupportRepId VARCHAR(100));
`

db.run(crateCustomerTableSQL, (error) => {
    if(error){
        console.log('Error', error)
        return
    }
    console.log('Successfully created Customer')
})


    db.run("SELECT * FROM Customer", [], (err, rows) => {
      if (err) {
        return console.error(err.message);
      }
      if(rows?.length === 0){
        const sqlInsert = `INSERT INTO Customer (FirstName, LastName, Company, Email) VALUES
        ('Adam', 'Nowak', 'Samsung', 'adam.nowak@samsung.com'),
        ('Jan', 'Kosmacz', 'Deloitte', 'jan.kosmacz@deloitte.com'),
        ('Jan', 'Kowalski', 'Sony', 'jan.kowalski@sony.com');`;
        
        db.run(sqlInsert, err => {
          if (err) {
            return console.error(err.message);
          }
          console.log("Successful creation of 3 customers");
        });
      }
    });




app.get('/customers', (req, res) => {
  const sql = `SELECT * FROM Customer ORDER BY FirstName`

  db.all(sql, [], (err, rows) => {
    if (err) {
      return console.error(err.message);
    }
    res.json({ model: rows });
  });
})


  
  app.post("/create", (req, res) => {     
    const sql = "INSERT INTO Customer (FirstName, LastName, Company, Email, Address, City, State, Country, PostalCode, Phone, Fax) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    const book = [req.body.FirstName, req.body.LastName, req.body.Company, req.body.Email, req.body.Address,  req.body.City, req.body.State, req.body.Country, req.body.PostalCode, req.body.Phone, req.body.Fax];


    db.run(sql, book, err => {
  
      res.json({ success: true });
    });
  });

  app.get('/customer', (req, res) => {
    const id = req.query.id
    
    if(!id){
      return res.json({model: "Couldn't find id!"})
    }
  
    const sql = `SELECT * FROM Customer WHERE CustomerId=?`
  
    db.all(sql, id, (err, rows) => {
      if (err) {
        return console.error(err.message);
      }
      res.json({ model: rows });
    });
  })

  app.delete("/delete", (req, res) => {
    const id = req.query.id
  
    console.log('id', req.query.id)

    if(!id){
      return res.json({model: "Couldn't find id!"})
    }

    const sql = `DELETE FROM Customer WHERE CustomerId=?`;

    db.run(sql, id, err => {

      if(err){
        console.log('err', err)
      }else{
      res.json({ success: true });
      }
    });
  });

  app.put("/edit", (req, res) => {
    const id = req.query.id
  

    if(!id){
      return res.json({model: "Couldn't find id!"})
    }
    const newData = [req.body.FirstName, req.body.LastName, req.body.Company, req.body.Email, req.body.Address,  req.body.City, req.body.State, req.body.Country, req.body.PostalCode, req.body.Phone, req.body.Fax, id];
  
    const sql = `UPDATE Customer SET FirstName=?, LastName=?, Company=?, Email=?, Address=?, City=?, State=?, Country=?, PostalCode=?, Phone=?, Fax=?
    WHERE CustomerId=?`

    db.run(sql, newData, err => {

      if(err){
        console.log('err', err)
      }else{
      res.json({ success: true });
      }
    });
  });

app.listen(4000, () => {
  console.log(`Example app listening at http://localhost:4000`)
})