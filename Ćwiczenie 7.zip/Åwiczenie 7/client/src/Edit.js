import React, { useEffect, useState } from "react";
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import axios from 'axios'

const Edit = () => {


    useEffect(() => {
        const id = window.location.href.split(":").pop()

        axios.get(`http://localhost:4000/customer?id=${id}`).then((res) => {

    
            const {FirstName, LastName, Company, Email,Country, State, City, PostalCode, Address, Phone, Fax } = res.data?.model[0] || {}
            setName(FirstName)
            setLastName(LastName)
            setCompany(Company)
            setEmail(Email)

            setCountry(Country)

            setState(State)
            setCity(City)
            setPostalCode(PostalCode)
            setAddress(Address)
            setPhone(Phone)
            setFax(Fax)


        })
        .catch(err => {
            console.log('err', err)
        })
    }, [])

    const [name, setName] = useState('')
    const [lastName, setLastName] = useState('')
    const [company, setCompany] = useState('')
    const [email, setEmail] = useState('')
    const [address, setAddress] = useState('')
    const [city, setCity] = useState('')
    const [country, setCountry] = useState('')
    const [state, setState] = useState('')
    const [postalCode, setPostalCode] = useState('')
    const [phone, setPhone] = useState('')
    const [fax, setFax] = useState('')


    console.log('name', name)

    const updateUser = () => {
        const id = window.location.href.split(":").pop()
        axios.put(`http://localhost:4000/edit?id=${id}`,  { FirstName: name, LastName: lastName, Company: company, Email: email, Address: address,
        City: city,
        State: state,
        Country: country,
        PostalCode: postalCode,
        Phone: phone,
        Fax: fax }).then((res) => {
            console.log('res', res)
        }).catch(err => {
            console.log('err', err)
        })
    }

return(
    <div>
          <Form id="submit-form">

            <Form.Group className="mb-3" controlId="formFirstName"   >
                <Form.Label>First Name</Form.Label>
                <Form.Control placeholder="Enter First Name"  value={name} onChange={(e) => setName(e.target.value)}    type="text"/>
            </Form.Group>

            <Form.Group className="mb-3" controlId="formLastName">
                <Form.Label>Last Name</Form.Label>
                <Form.Control placeholder="Enter Last Name"  value={lastName} onChange={(e) => setLastName(e.target.value)} type="text"/>
            </Form.Group>

            <Form.Group className="mb-3" controlId="formCompany" >
                <Form.Label>Company</Form.Label>
                <Form.Control placeholder="Enter Company" value={company} onChange={(e) => setCompany(e.target.value)} type="text"/>
            </Form.Group>

            <Form.Group className="mb-3" controlId="formBasicEmail" >
                <Form.Label>Email address</Form.Label>
                <Form.Control type="email" placeholder="Enter email" value={email} onChange={(e) => setEmail(e.target.value)} type="text"/>
            </Form.Group>

            <Form.Group className="mb-3" controlId="formBasicEmail" >
                <Form.Label>Country</Form.Label>
                <Form.Control placeholder="Enter Country" value={country} onChange={(e) => setCountry(e.target.value)} type="text"/>
            </Form.Group>

            <Form.Group className="mb-3" controlId="formBasicEmail" >
                <Form.Label>State</Form.Label>
                <Form.Control placeholder="Enter State" value={state} onChange={(e) => setState(e.target.value)} type="text"/>
            </Form.Group>

            <Form.Group className="mb-3" controlId="formBasicEmail" >
                <Form.Label>City</Form.Label>
                <Form.Control placeholder="Enter City" value={city} onChange={(e) => setCity(e.target.value)} type="text"/>
            </Form.Group>

            <Form.Group className="mb-3" controlId="formBasicEmail" >
                <Form.Label>PostalCode</Form.Label>
                <Form.Control placeholder="Enter PostalCode" value={postalCode} onChange={(e) => setPostalCode(e.target.value)} type="text"/>
            </Form.Group>

            <Form.Group className="mb-3" controlId="formBasicEmail" >
                <Form.Label>Address</Form.Label>
                <Form.Control placeholder="Enter Address" value={address} onChange={(e) => setAddress(e.target.value)} type="text"/>
            </Form.Group>

            <Form.Group className="mb-3" controlId="formBasicEmail" >
                <Form.Label>Phone</Form.Label>
                <Form.Control placeholder="Enter Phone" value={phone} onChange={(e) => setPhone(e.target.value)} type="text"/>
            </Form.Group>

            <Form.Group className="mb-3" controlId="formBasicEmail" >
                <Form.Label>Fax</Form.Label>
                <Form.Control placeholder="Enter Fax" value={fax} onChange={(e) => setFax(e.target.value)} type="text"/>
            </Form.Group>
            
  
            </Form>

            <Button variant="primary" type="submit" form="submit-form" onClick={(e) => {
                e.preventDefault()
                updateUser()}}>
            Submit
          </Button>
    </div>
)
}


export default Edit