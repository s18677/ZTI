import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import DetailedInfo from './DetailedInfo';
import Edit from './Edit';
import { Routes, Route, Link } from "react-router-dom";
import { BrowserRouter } from "react-router-dom";

ReactDOM.render(
  <React.StrictMode>
    <BrowserRouter>
     <Routes>
        <Route path="/" element={<App />} />
        <Route path="/details/:id" element={<DetailedInfo />} />
        <Route path="/edit/:id" element={<Edit />} />
      </Routes>
      </BrowserRouter>
  </React.StrictMode>,
  document.getElementById('root')
);
 